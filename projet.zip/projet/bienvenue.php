<!-- Sur cette page, on accueil notre utlisateur -->
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>Bienvenue</title>
        <link rel ="stylesheet" href ="bienvenue.css">
        <div class="tete">
            <img src="images/logo.png" alt="logo" width="180" height="180">
            <h1>Pensées Croisées:<br>Pour qu'aucune question intelligente ne reste sans réponse!<h1><br>
        </div>
    </head>
    <body>
        <table>
            <tr><td>Vous avez déjà un compte?</td><td>C'est votre première visite?</td></tr>
            <tr><td><a href="http://localhost/projet/connexion.php"><button type="button" class="buttons">Me connecter</button></a></td><td><a href="http://localhost/projet/inscription.php"><button type="button" class="buttons">M'inscrire</button></a></td></tr>
        </table>
    </body>
</html>